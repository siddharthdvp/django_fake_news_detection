#!/usr/bin/env python3
"""File cleaner script"""
import os
import sqlite3

# name/path of the sql3 database file
database = "db.sqlite3"

home = os.getcwd()
print(f"I: Current working directory {home}")

connection = sqlite3.connect(database)

def remove_file(base_dir, file):
    file = os.path.join(base_dir, file)
    if os.path.exists(file) and os.path.isfile(file):
        print(f"I: Removing: {file}")
        os.remove(file)


def clean_files(dir, table, columns):
    """provide directory, table name, image column name"""
    print(f"I: Cleaning unused files under {dir}")
    try:
        mycursor = connection.cursor()
        mycursor.execute(f"SELECT {columns} FROM {table}")
        query_result = mycursor.fetchall()
        dir_path = os.path.join(home, dir)
        file_list = [
            file
            for file in os.listdir(dir_path)
            if os.path.isfile(os.path.join(dir_path, file))
        ]

        if query_result:
            query_list = []
            for q in query_result:
                query_item = q[0].split("/")[-1]
                query_list.append(query_item)

            for file in file_list:
                if file not in query_list:
                    remove_file(dir_path, file)
        else:
            for file in file_list:
                remove_file(dir_path, file)

    except:
        raise TypeError("Incorrect table or column")


################# Clean unused files/images #################
clean_files("media/image", "core_post", "image")
clean_files("media/pdf", "core_reportnews", "image_or_pdf")
#############################################################

# Close the connection
connection.close()
print("S: Done.!")
exit()
