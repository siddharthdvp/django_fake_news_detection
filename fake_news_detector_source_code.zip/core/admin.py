from django.contrib import admin
from django.utils.translation import gettext_lazy as _
from django.contrib.auth.admin import UserAdmin
from .models import User, Post, ReportNews, LikePost, CommentPost

# Register your models here.
@admin.register(User)
class CustomUserAdmin(UserAdmin):
    fieldsets = (
        (None, {"fields": ("username", "password")}),
        (_("Personal info"), {"fields": ("name", "email")}),
        (
            _("Permissions"),
            {
                "fields": (
                    "is_active",
                    "is_staff",
                    "is_superuser",
                    "groups",
                    "user_permissions",
                ),
            },
        ),
        (_("Important dates"), {"fields": ("last_login", "date_joined")}),
    )
    list_display = ("username", "email", "name", "is_staff")
    search_fields = ("username", "email", "name")
    add_fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": ("username", "name", "email", "password1", "password2"),
            },
        ),
    )


@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ["id", "title", "post_by", "publish_date"]
    list_display_links = ["id", "title"]
    search_fields = ["title", "short_description"]


@admin.register(ReportNews)
class ReportNewsAdmin(admin.ModelAdmin):
    list_display = ["id", "title", "reported_by", "reported_on"]
    list_display_links = ["id", "title"]
    search_fields = ["title", "source"]


@admin.register(LikePost)
class LikePostAdmin(admin.ModelAdmin):
    list_display = ["id", "post", "user", "created_on"]


@admin.register(CommentPost)
class CommentPostAdmin(admin.ModelAdmin):
    list_display = ["id", "user", "post", "commented_on"]
    list_display_links = ["id", "user"]
    search_fields = ["comment"]
