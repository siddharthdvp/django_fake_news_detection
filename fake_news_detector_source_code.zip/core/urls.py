from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from . import views

urlpatterns = [
    path('', views.HomeView.as_view(), name='home'),
    path('signup/', views.CustomSignupView.as_view(), name='signup'),
    path('login/', views.CustomLoginView.as_view(), name='login'),
    path('logout/', views.CustomLogoutView.as_view(), name='logout'),
    path('admin-dashboard/reports/', views.AdminDashboardManageReportView.as_view(), name='admin_dashboard_manage_report'),
    path('admin-dashboard/posts/', views.AdminDashboardManagePostView.as_view(), name='admin_dashboard_manage_post'),
    path('admin-dashboard/posts/add/', views.AddPostView.as_view(), name='addpost'),
    path('admin-dashboard/posts/edit/<pk>/', views.EditPostView.as_view(), name='editpost'),
    path('admin-dashboard/posts/delete/', views.DeletePostView.as_view(), name='deletepost'),
    path('admin-dashboard/reports/delete/', views.DeleteReportView.as_view(), name='deletereport'),
    path('dashboard/', views.UserDashboardView.as_view(), name='user_dashboard'),
    path('dashboard/create-report/', views.AddReportView.as_view(), name='addreport'),
    path('my-report/<pk>/', views.ReportView.as_view(), name='report'),
    path('news-report/<pk>/', views.ReportView.as_view(), name='report_view_for_admin'),
    path('search/', views.SearchView.as_view(), name='search'),
    path('account/delete/', views.DeleteUserView.as_view(), name='delete_user_account'),
    path('api/like-post/<pk>/', views.LikePostView.as_view(), name="like_post"),
    path('api/fetch-like/<pk>/', views.FetchLikeView.as_view(), name="fetch_like"),
    path("comment/delete/<pk>/", views.DeleteCommentView.as_view(), name="deletecomment"),
    path('<slug>/', views.PostView.as_view(), name='post'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
