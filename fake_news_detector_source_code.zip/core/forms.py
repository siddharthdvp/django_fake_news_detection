from django import forms
from .models import User, Post, ReportNews, CommentPost
from django.contrib.auth.forms import UserCreationForm
from .email_auth_form import EmailAuthenticationForm
from django.utils.translation import gettext_lazy as _


class UserSignupForm(UserCreationForm):
    password1 = forms.CharField(
        label=_("Password"), widget=forms.PasswordInput(attrs={"class": "form-control"})
    )
    password2 = forms.CharField(
        label=_("Confirm Password"),
        widget=forms.PasswordInput(attrs={"class": "form-control"}),
    )

    class Meta:
        model = User
        fields = ["username", "name", "email", "password1", "password2"]
        widgets = {
            "username": forms.TextInput(attrs={"class": "form-control"}),
            "name": forms.TextInput(attrs={"class": "form-control"}),
            "email": forms.EmailInput(attrs={"class": "form-control"}),
        }


class UserLoginForm(EmailAuthenticationForm):
    email = forms.EmailField(widget=forms.EmailInput(attrs={"class": "form-control"}))
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={"class": "form-control"})
    )
    field_order = ["email", "password"]


class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = [
            "title",
            "short_description",
            "image",
            "description",
            "slug",
        ]
        widgets = {
            "title": forms.TextInput(
                attrs={"class": "form-control", "placeholder": "Enter title"}
            ),
            "short_description": forms.TextInput(
                attrs={"class": "form-control", "placeholder": "About the post"}
            ),
            "image": forms.FileInput(attrs={"class": "form-control"}),
            "description": forms.Textarea(
                attrs={
                    "class": "form-control",
                    "placeholder": "Enter post description",
                    "rows": 5,
                }
            ),
            "slug": forms.TextInput(
                attrs={"class": "form-control", "placeholder": "Enter slug (url)"}
            ),
        }


class ReportNewsForm(forms.ModelForm):
    class Meta:
        model = ReportNews
        fields = ['title', 'source', 'image_or_pdf', 'other_information']
        labels = {
            "image_or_pdf": "Image/PDF"
        }
        widgets = {
            "title": forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter the news title'}),
            "source": forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter the news source'}),
            "image_or_pdf": forms.FileInput(attrs={'class': 'form-control', 'accept': 'application/pdf, image/png, image/jpeg'}),
            "other_information": forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Describe the report (optional)', 'rows': 5}),
        }


class CommentPostForm(forms.ModelForm):
    class Meta:
        model = CommentPost
        fields = ['comment']
        widgets = {
            "comment": forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Write your comment here...', 'rows': 3})
        }
