from django.db import models
from django.contrib.auth.models import AbstractUser
from uuid import uuid4
from datetime import datetime
from django.core.exceptions import ValidationError
import os


# helper function; used to rename user provided file during upload
def rename_on_upload(self, file_name):
    ext_name = file_name.split(".")[-1]
    image_exts = ["jpg", "png", "jpeg"]
    if ext_name in image_exts:
        upload_dir = "image"
    elif "pdf" == ext_name:
        upload_dir = "pdf"
    else:
        upload_dir = "other"
    datetime_now = datetime.now()
    file_name_string = "{}{}.{}".format(
        datetime_now.strftime("%Y%m%d%H%M%S"), uuid4().hex, ext_name
    )
    return os.path.join(upload_dir, file_name_string)


# helper function; used to check the file size and respond on the basis of maximum allowed limit
def validate_file_size_on_upload(value):
    file_size = value.size
    if file_size > 1572864:
        raise ValidationError("Please keep the file size under 1.5MB")
    else:
        return value


# Create your models here.
class User(AbstractUser):
    first_name = None
    last_name = None
    name = models.CharField(max_length=60)
    email = models.EmailField(max_length=75, unique=True)


class Post(models.Model):
    title = models.CharField(max_length=250)
    short_description = models.CharField(max_length=300)
    image = models.ImageField(upload_to=rename_on_upload, blank=True, null=True)
    description = models.TextField()
    publish_date = models.DateTimeField(auto_now_add=True)
    last_updated = models.DateTimeField(auto_now=True, null=True)
    slug = models.SlugField(
        max_length=150,
        unique=True,
        help_text="Should not contain any spaces or special characters, use hyphens instead",
    )
    post_by = models.ForeignKey(User, on_delete=models.PROTECT)
    def __str__(self):
        return self.title


class ReportNews(models.Model):
    title = models.TextField(max_length=250)
    source = models.TextField(max_length=400)
    image_or_pdf = models.FileField(upload_to=rename_on_upload, validators=[validate_file_size_on_upload], help_text="max 1.5MB")
    other_information = models.TextField(null=True, blank=True)
    reported_on = models.DateTimeField(auto_now_add=True)
    reported_by = models.ForeignKey(User, on_delete=models.CASCADE)
    def __str__(self):
        return self.title


class LikePost(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    created_on = models.DateTimeField(auto_now_add=True)


class CommentPost(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    comment = models.TextField(max_length=10000)
    commented_on = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Comment by {self.user.username}"

