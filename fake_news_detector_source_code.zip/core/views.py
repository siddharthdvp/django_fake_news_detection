from django.http.response import HttpResponseRedirect, JsonResponse
from django.shortcuts import redirect, render
from django.views.generic import View, ListView, DetailView
from django.contrib.auth.views import LogoutView, LoginView
from .models import User, Post, ReportNews, LikePost, CommentPost
from .forms import UserLoginForm, UserSignupForm, PostForm, ReportNewsForm, CommentPostForm
from django.contrib.auth.models import Group
from django.urls import reverse_lazy
from django.utils.translation import gettext as _
from django.http import Http404
from django.shortcuts import get_object_or_404
from datetime import timedelta
from django.utils.timezone import now
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.decorators.cache import never_cache
from django.utils.decorators import method_decorator
from django.contrib import messages
####################################################

# Create your views here.
class HomeView(ListView):
    template_name = 'core/home.html'
    paginate_by = 50
    ordering = ['-id']
    paginate_orphans = 5
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.queryset = Post.objects.all()


class ReportView(DetailView):
    model = ReportNews
    template_name = 'core/viewreport.html'


class CustomLogoutView(LogoutView):
    """Inherits LogoutView"""

    next_page = 'login'


@method_decorator(never_cache, name='dispatch')
class CustomLoginView(LoginView):
    form_class = UserLoginForm
    template_name = 'core/login.html'


class CustomSignupView(View):
    form_class = UserSignupForm
    template_name = 'core/signup.html'
    success_url = reverse_lazy('signup')
    success_message = 'Your account has been created! you can now login.'
    error_message = 'Failed to create account!'

    def get(self, request):
        # Redirect user to home page if already authenticated
        if request.user.is_authenticated:
            return HttpResponseRedirect('/')

        form = self.form_class
        context = {'form': form}
        return render(request, self.template_name, context)

    def post(self, request):
        form = self.form_class(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.save()
            user_group = Group.objects.get(name='Basic')
            user.groups.add(user_group)
            messages.success(request, self.success_message)
            return HttpResponseRedirect(reverse_lazy('login'))
        messages.error(request, self.error_message)
        context = {'form': form}
        return render(request, self.template_name, context)


@method_decorator(never_cache, name='dispatch')
class AddPostView(LoginRequiredMixin, View):
    login_url = '/login/'
    template_name = 'core/admin/addpost.html'
    success_message = 'Post added successfully.'
    error_message = 'Please correct the errors below!'

    def get(self, request):
        form = PostForm
        context = {'form': form}
        return render(request, self.template_name, context)

    def post(self, request):
        request_user = request.user
        form = PostForm(request.POST, request.FILES)
        if request_user.has_perm('core.add_post'):
            if form.is_valid():
                title = form.cleaned_data['title']
                short_description = form.cleaned_data['short_description']
                image = form.cleaned_data['image']
                description = form.cleaned_data['description']
                slug = form.cleaned_data['slug']
                obj = Post(
                    title=title,
                    short_description=short_description,
                    image=image,
                    description=description,
                    slug=slug,
                    post_by=request_user,
                )
                obj.save()
                messages.success(request, self.success_message)
            else:
                messages.error(request, self.error_message)
        else:
            messages.error(
                request, 'You don\'t have enough permissions to perform this action!'
            )
        context = {'form': form}
        return render(request, self.template_name, context)


@method_decorator(never_cache, name='dispatch')
class EditPostView(LoginRequiredMixin, View):
    login_url = reverse_lazy('login')
    template_name = 'core/admin/editpost.html'

    def get(self, request, pk):
        post_instance = Post.objects.get(pk=pk)
        form = PostForm(instance=post_instance)
        context = {'form': form, 'image': post_instance.image}
        return render(request, self.template_name, context)

    def post(self, request, pk):
        request_user = request.user
        next_url = request.GET.get('next')
        post_instance = Post.objects.get(pk=pk)
        clear_image = request.POST.get('clear_image')
        form = PostForm(request.POST, request.FILES, instance=post_instance)
        context = {'form': form, 'image': post_instance.image}
        if request_user.has_perm('core.change_post'):
            if form.is_valid():
                post_obj = form.save(commit=False)
                if clear_image:
                    # Post.objects.filter(pk=pk).update(image="")
                    post_obj.update(image="")
                post_obj.save()
                messages.success(request, 'Post updated successfully.')
            else:
                messages.error(request, 'Unable to update the post!')
            if next_url:
                return HttpResponseRedirect(next_url)
            updated_post_instance = Post.objects.get(pk=id)
            context = {'form': form, 'image': updated_post_instance.image}
        else:
            messages.error(
                request, 'You don\'t have enough permissions to perform this action!'
            )
        return render(request, self.template_name, context)


class DeletePostView(LoginRequiredMixin, View):
    login_url = reverse_lazy('login')
    redirect_url = reverse_lazy('admin_dashboard_manage_post')
    success_message = 'Post deleted successfully.'

    def post(self, request):
        if request.user.is_staff:
            if request.user.has_perm('core.delete_post'):
                obj_id = request.POST.get('post_id')
                if Post.objects.filter(pk=obj_id).exists():
                    Post(pk=obj_id).delete()
                    messages.success(request, self.success_message)
                else:
                    messages.error(request, 'Unable to delete, post does not exist!')
            else:
                messages.error(
                    request,
                    'You don\'t have delete permission to perform this operation!',
                )
        else:
            messages.error(
                request,
                'You\'ll need to be a staff or an admin to perform this operation!',
            )
        return HttpResponseRedirect(self.redirect_url)


class DeleteReportView(LoginRequiredMixin, View):
    login_url = reverse_lazy('login')
    redirect_url = reverse_lazy('admin_dashboard_manage_report')
    success_message = 'Report deleted successfully.'

    def post(self, request):
        if request.user.is_staff:
            if request.user.has_perm('core.delete_reportnews'):
                obj_id = request.POST.get('report_id')
                if ReportNews.objects.filter(pk=obj_id).exists():
                    ReportNews(pk=obj_id).delete()
                    messages.success(request, self.success_message)
                else:
                    messages.error(request, 'Unable to delete, report does not exist!')
            else:
                messages.error(
                    request,
                    'You don\'t have delete permission to perform this operation!',
                )
        else:
            messages.error(
                request,
                'You\'ll need to be a staff or an admin to perform this operation!',
            )
        return HttpResponseRedirect(self.redirect_url)


class AdminDashboardManagePostView(LoginRequiredMixin, ListView):
    login_url = reverse_lazy('login')
    template_name = 'core/admin/manage_post_dashboard.html'
    paginate_by = 30
    paginate_orphans = 5
    allow_empty = True

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.queryset = Post.objects.all().order_by("-id")

    def get(self, request, *args, **kwargs):
        self.object_list = self.get_queryset()
        allow_empty = self.get_allow_empty()

        if not allow_empty:
            # When pagination is enabled and object_list is a queryset,
            # it's better to do a cheap query than to load the unpaginated
            # queryset in memory.
            if self.get_paginate_by(self.object_list) is not None and hasattr(
                self.object_list, 'exists'
            ):
                is_empty = not self.object_list.exists()
            else:
                is_empty = not self.object_list
            if is_empty:
                raise Http404(
                    _("Empty list and “%(class_name)s.allow_empty” is False.")
                    % {
                        "class_name": self.__class__.__name__,
                    }
                )
        context = self.get_context_data()
        context.update({'page_type': 'manage_post'})
        return self.render_to_response(context)


@method_decorator(never_cache, name='dispatch')
class AdminDashboardManageReportView(LoginRequiredMixin, ListView):
    login_url = reverse_lazy('login')
    template_name = 'core/admin/manage_report_dashboard.html'
    paginate_by = 40
    paginate_orphans = 5
    allow_empty = True

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.queryset = ReportNews.objects.all().order_by('-id')

    def get(self, request, *args, **kwargs):
        self.object_list = self.get_queryset()
        allow_empty = self.get_allow_empty()

        if not allow_empty:
            # When pagination is enabled and object_list is a queryset,
            # it's better to do a cheap query than to load the unpaginated
            # queryset in memory.
            if self.get_paginate_by(self.object_list) is not None and hasattr(
                self.object_list, 'exists'
            ):
                is_empty = not self.object_list.exists()
            else:
                is_empty = not self.object_list
            if is_empty:
                raise Http404(
                    _("Empty list and “%(class_name)s.allow_empty” is False.")
                    % {
                        "class_name": self.__class__.__name__,
                    }
                )
        context = self.get_context_data()
        context.update({'page_type': 'manage_report'})
        return self.render_to_response(context)


class AddReportView(LoginRequiredMixin, View):
    login_url = '/login/'
    template_name = 'core/newreport.html'
    success_message = 'Your report has been submitted.'
    error_message = 'Please correct the errors below!'

    def get(self, request):
        form = ReportNewsForm
        context = {'form': form}
        return render(request, self.template_name, context)

    def post(self, request):
        request_user = request.user
        next_url = request.GET.get('next')
        request_user = request.user
        form = ReportNewsForm(request.POST, request.FILES)
        if not request_user.has_perm('core.add_reportnews'):
            messages.error(
                request, 'You don\'t have enough permissions to perform this action!'
            )
            return HttpResponseRedirect(reverse_lazy('user_dashboard'))

        reports_in_last_24_hours = request_user.reportnews_set.filter(
            reported_on__gt=now() - timedelta(days=1)
        )
        if reports_in_last_24_hours.count() >= 5:
            messages.error(
                request,
                'You\'ve reached the maximum 5 reports per day (24hrs) limit, please try again tomorrow!',
            )
        else:
            if form.is_valid():
                title = form.cleaned_data['title']
                source_url = form.cleaned_data['source']
                image_or_pdf = form.cleaned_data['image_or_pdf']
                other_information = form.cleaned_data['other_information']
                obj = ReportNews(
                    title=title,
                    source=source_url,
                    image_or_pdf=image_or_pdf,
                    other_information=other_information,
                    reported_by=request_user,
                )
                obj.save()
                messages.success(request, self.success_message)
                if next_url:
                    return HttpResponseRedirect(next_url)
            else:
                messages.error(request, self.error_message)
        context = {'form': form}
        return render(request, self.template_name, context)


@method_decorator(never_cache, name='dispatch')
class UserDashboardView(LoginRequiredMixin, ListView):
    login_url = reverse_lazy('login')
    template_name = 'core/dashboard.html'
    paginate_by = 25
    paginate_orphans = 5
    allow_empty = True

    def get(self, request, *args, **kwargs):
        # self.object_list = self.get_queryset()
        self.object_list = ReportNews.objects.filter(reported_by=request.user).order_by(
            '-id'
        )
        allow_empty = self.get_allow_empty()

        if not allow_empty:
            # When pagination is enabled and object_list is a queryset,
            # it's better to do a cheap query than to load the unpaginated
            # queryset in memory.
            if self.get_paginate_by(self.object_list) is not None and hasattr(
                self.object_list, 'exists'
            ):
                is_empty = not self.object_list.exists()
            else:
                is_empty = not self.object_list
            if is_empty:
                raise Http404(
                    _("Empty list and “%(class_name)s.allow_empty” is False.")
                    % {
                        "class_name": self.__class__.__name__,
                    }
                )
        context = self.get_context_data()
        return self.render_to_response(context)


class SearchView(ListView):
    model = Post
    template_name = 'core/search.html'
    paginate_by = 15
    paginate_orphans = 5
    allow_empty = True

    def get(self, request, *args, **kwargs):
        search_value = request.GET.get('q')
        self.queryset = Post.objects.filter(title__icontains=search_value).order_by('-id')
        self.object_list = self.get_queryset()
        allow_empty = self.get_allow_empty()

        if not allow_empty:
            # When pagination is enabled and object_list is a queryset,
            # it's better to do a cheap query than to load the unpaginated
            # queryset in memory.
            if self.get_paginate_by(self.object_list) is not None and hasattr(
                self.object_list, 'exists'
            ):
                is_empty = not self.object_list.exists()
            else:
                is_empty = not self.object_list
            if is_empty:
                raise Http404(
                    _("Empty list and “%(class_name)s.allow_empty” is False.")
                    % {
                        "class_name": self.__class__.__name__,
                    }
                )
        context = self.get_context_data()
        context.update({'page_title': f'Search Result for "{search_value}"'})
        return self.render_to_response(context)


class DeleteUserView(LoginRequiredMixin, View):
    login_url = reverse_lazy('login')
    redirect_url = login_url
    success_message = 'Your account has been deleted successfully.'

    def post(self, request):
        obj_id = request.POST.get('user_id')
        if obj_id:
            if User.objects.filter(pk=obj_id).exists():
                User(pk=obj_id).delete()
                messages.success(request, self.success_message)
        else:
            messages.error(request, 'Unable to delete the account, contact site admin!')
        return HttpResponseRedirect(self.redirect_url)


class DeleteCommentView(LoginRequiredMixin, View):
    login_url = reverse_lazy('login')
    redirect_url = login_url
    success_message = 'Your comment has been deleted.'

    def post(self, request, pk):
        request_user = request.user
        post_slug = request.POST.get('post_slug')
        post_instance = get_object_or_404(Post, slug=post_slug)
        comment_instance = get_object_or_404(CommentPost, id=pk, post=post_instance, user=request_user)
        comment_instance.delete()
        messages.success(request, self.success_message)
        return redirect(reverse_lazy('post', kwargs={'slug': post_slug}))


class PostView(View):
    template_name = 'core/viewpost.html'
    def get(self, request, slug):
        request_user = request.user
        comment_form = CommentPostForm
        post = get_object_or_404(Post, slug=slug)
        posted_comments = CommentPost.objects.filter(post=post).order_by('-commented_on')
        is_liked = False
        if request_user.is_authenticated:
            is_liked = LikePost.objects.filter(user=request_user, post=post).exists()
        
        total_likes = LikePost.objects.filter(post=post).count()
        context = {'post': post, 'total_likes': total_likes, 'is_liked': is_liked, 'form': comment_form, 'comments': posted_comments}
        return render(request, self.template_name, context)
    
    def post(self, request, slug):
        request_user = request.user
        comment_form = CommentPostForm(request.POST)
        post_instance = Post.objects.get(slug=slug)
        if comment_form.is_valid():
            comment = comment_form.cleaned_data['comment']
            comment_obj = CommentPost(user=request_user, post=post_instance, comment=comment)
            comment_obj.save()
            messages.success(request, 'Your comment has been posted.')
        else:
            messages.error(request, 'Unable to post your comment!')
        return redirect(reverse_lazy('post', kwargs={'slug': slug}))


class LikePostView(View):
    def post(self, request, pk):
        request_user = request.user
        post_instance = Post(pk=pk)
        if request_user.is_authenticated:
            if post_instance:
                like_obj, created = LikePost.objects.get_or_create(user=request_user, post_id=pk)
                if created:
                    response = {'code': 'created'}
                    status_code = 201
                else:
                    # remove the like
                    like_obj.delete()
                    response = {'code': 'like_removed'}
                    status_code = 200
            else:
                response = {'code': 'post_not_exist'}
                status_code = 404
        else:
            response = {'code': 'user_not_exist'}
            status_code = 404
        return JsonResponse(response, status=status_code)


class FetchLikeView(View):
    def get(self, request, pk):
        post_instance = Post.objects.get(pk=pk)
        if post_instance:
            likes = post_instance.likepost_set.all().count()
            return JsonResponse({'likes': likes}, status=200)
        else:
            return JsonResponse({'code': 'post_not_exist'}, status=404)


####### Customized 404 error page #######
def page_not_found(request, exception):
    return render(request, 'core/404.html')


####### Customized 500 error pages #######
def server_error(request):
    return render(request, 'core/500.html')
