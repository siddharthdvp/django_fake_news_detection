// main.js
// fetch('http://127.0.0.1:8000/api/like-post/{{post.id}}', {
//   method: 'POST',
//   headers: { 'X-CSRFToken': '' },
//   mode: 'same-origin', // Do not send CSRF token to another domain.
//   body: ''
// })
//   .then((res) =>
//     res.json().then((data) => ({ status: res.status, data: data }))
//   )
//   .then((response) => {
//     console.log('Liked')
//   })
//   .catch((err) => {
//     console.log('Got an error')
//     console.log(err)
//   })
